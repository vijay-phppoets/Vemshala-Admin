import React from "react"

// @custom-component-imports ------------------------------------------------------------------------ 

    import Header from "../../../component/Header/Header"
    import { PageContainer } from "../../../component/Xcomponent"

// --------------------------------------------------------------------------------------------------

const CouponsEdit = () => {
    return (
        <React.Fragment>
            <Header title="New Coupons"></Header>
            <PageContainer></PageContainer>
        </React.Fragment>
)}

export default CouponsEdit